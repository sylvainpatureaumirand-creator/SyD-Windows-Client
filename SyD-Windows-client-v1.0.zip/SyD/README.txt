Le SyD est le client d'une IGCS et de son Serveur de Service

Il est necessaire de configurer dans le fichier ./conf/ServerSYD.cfg les �l�ments suivants :
{
"uuid":"853896a6-5ddb-4d0b-9516-52fc46cbe9b6",
"IP":"82.67.97.63",
"PORT":"5110"
}
l'uuid etant celui du serveurSYD qui lui est attibu� lors de son initialisation (les �l�ments sont disponibles sur la pages de garde du serveur SYD)

il en est de meme pour le Serveur de service

{
"uuid":"5c8e6a90-09c2-4482-b122-02af772c19ea",
"IP":"82.67.97.63",
"PORT":"5120",
}

Les uuid des serveurs sont a lire sur la page web des serveurs.

dans le fichier safe se trouve une clef permettant de securiser une partie des �l�ments de la base de donn�e.
{
"SAFE":"UnSuperMotDePassequiestrobusteOuPas"
}
Remplacer UnSuperMotDePassequiestrobusteOuPas par ce qu'il vous plait.
Cela doit �tre fait imp�rativement avant l'initialisation du client.

Pour se faire lancez le Createur.exe
aller en haut a gauche dans Menu
cliquez sur initialiser. Pour valider que tout c'est bien pass� en plus du message de retour.
Vous trouverez dans Mon identifiant une chaine du type UUID
( par exemple : 8e9ff375-205f-4a4c-b1d7-2ec6d5c41d64 )
Vous pouvez lancer le gestionnaire et vous pouvez faire la demande 
d'un conteneur SyD en cliquant sur Cr�er.

Enregistrez les document en quelquechose.syd et associez SyD.exe � son ouverture.

En usage, un conteneur contient un seul fichier. Il est limit� � une taille de 50Mo.
Il est possible de contourner le fait d'avoir un seul fichier en mettat un zip/tar/rar.
 
Il estpossible aussi de copier le .syd a x exemplaires. 
Mais cela veut dire que c'est toujours la meme clef de chiffrement qui est utilis�e in fin�.
Donc si celle ci est cass�e, tous les fichiers SyD duppliqu�s sont compromis.

Il est possible en ajoutant dans l'annuaire des identifiants de clients de la meme IGCS 
de cr�er des SyD qui sont ouvrables aussi par ces personnes.

Ouvrez l'annuaire, ajoutez dans la colone type : CL, dans le champs UUID celui de la personne � laquelle vous voulez partager.

Avant de faire Cr�er le SyD, selectionnez dans la colonne de gauche les personnes que vous voulez, et faites cr�er.

si vous souhaitez v�rifier vous pouvez ouvrir le .syd avec un blocnote et dans la ligne USER vous devez retouver plusieurs UUIDs. 
Le votre �tant en dernier.
 
